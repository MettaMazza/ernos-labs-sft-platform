# Mathematics branch

Mathematics is reconstructed from the admitted Foundation in a fixed dependency
order. Conventional names appear only as post-derivation correspondence; they
do not select any candidate, rule, proof value or boundary.

The archived v1 claim-set inventory has twelve obligations. The branch remains
open for full V1/V2 owner and same-strength reconciliation:

1. `exact_arithmetic/` — exact positive traces, parts, refinement and held remainder;
2. `discrete_mathematics/` — canonical finite collections, relations, maps and induction;
3. `combinatorics/` — exhaustive held-choice families and recurrence;
4. `graph_network/` — graphs, paths, reachability, cycles, cuts and balance;
5. `algebraic_structures/` — complete operation tables and witnessed properties;
6. `order_lattice/` — partial orders, conditional totality, meet and join;
7. `geometry_topology/` — finite incidence, paths, open families and continuity;
8. `probability_statistics/` — exact observation-support uncertainty and statistics;
9. `optimization/` — feasibility, dominance, retained optima and exact bounds;
10. `dynamical_systems/` — states, trajectories, recurrence, records and stability;
11. `logic_proof/` — distinguished propositions and replayable proof traces; and
12. `category_type_composition/` — objects, arrows, types and exact composition.

`catalog.py` is the dependency-ordered machine inventory. Every module declares
a complete product grammar, exactly one all-preserving survivor, minimality and
named-shape uniqueness, a depth-independent base/successor certificate, explicit
domain exclusions, operational witnesses and four adverse controls. The shared
`generated_law.py` module supplies engine plumbing only; scientific choices live
in their category-specific law modules.

The SFT proof domain contains structural One, exact positive finite counts and
parts, generated labels, fibres, branches, words, relations and forms. Semantic
numerical zero, negative quantities, irrational or imaginary proof values,
floating proof arithmetic, completed infinity and ungenerated continua are not
admitted. Empty and identity cases use the structural empty-One form. Held
orientation replaces signed magnitude.

Probability in this branch is not an imported stochastic cause. It is the exact
held-support/whole-support relation induced by observation over a complete
deterministic generated microstate support. Natural measurements may challenge a
sealed formal law only through the repository's preregistered blind empirical
route; they cannot choose the law.

## Open extension: exact scientific calculator

The calculator lineage is the admitted executable translation of these laws.
`SFT-MATH-SCIENTIFIC-CALCULATOR-003` is preserved as superseded adverse
evidence after an enclosure-parity defect was found. Corrected core `004`,
scientific surface `005`, complete calculator and law explorer `006`, and the
accessible local-browser adapter `007` form the current versioned lineage.

The current application is launched from `calculator_browser/`. It retains
exact rational values, structural empty-One, certified non-rational intervals,
typed orthogonal fibres, mandatory domain/resource halts and complete
operation/resource traces. A result crossing below empty One halts
transactionally and cannot enter answer, memory or history. The standards-
rendered interface works on macOS, Windows, Linux and same-network phones using
Python's standard library and the installed browser. It performs no browser-
side arithmetic and routes every action through immutable claim 006.

Calculator proof output is exact computational evidence, not a new engine
admission. A proposed law still requires registration, complete enumeration,
uniqueness, controls, independent validation and an official receipt from the
untouched engine. Historical Mathematics releases remain immutable while the
branch stays open to lawful extensions.
