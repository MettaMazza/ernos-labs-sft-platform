# Engineering interface

Claim: `SFT-ENG-INTERFACE-001`

## Why

An interface is a typed exchange contract retaining endpoints, units, timing, errors and version.

## Derivation

Dependencies: `SFT-FOUNDATION-ONE-001`, `SFT-FOUNDATION-FOLD-001`, `SFT-FOUNDATION-FOLD-DYNAMICS-001`, `SFT-MATH-EXACT-ARITHMETIC-001`, `SFT-MATH-GRAPH-NETWORK-001`, `SFT-MATH-OPTIMIZATION-001`, `SFT-MATH-DYNAMICAL-SYSTEMS-001`, `SFT-MATH-LOGIC-PROOF-001`, `SFT-INFO-QUANTITY-001`, `SFT-INFO-CHANNEL-CAPACITY-001`, `SFT-COMP-FORM-STATE-TRANSITION-001`, `SFT-COMP-SEM-CORRECTNESS-001`, `SFT-COMP-SEM-COMPILATION-001`, `SFT-COMP-DIST-CAUSALITY-001`, `SFT-PHYS-MEAS-VALUE-RECORD-001`, `SFT-PHYS-MEAS-CALIBRATION-001`, `SFT-CHEM-MEAS-TRACEABILITY-001`, `SFT-MAT-SUST-LIFECYCLE-001`, `SFT-BIO-BIO-HANDOFF-001`, `SFT-CONSC-RED-EMPIRICAL-BOUNDARY-001`, `SFT-MED-CLINICAL-EVIDENCE-HANDOFF-001`, `SFT-EARTH-HAZARD-RISK-HANDOFF-001`, `SFT-ASTRO-ASTRO-HANDOFF-001`, `SFT-SOCIAL-ENGINEERING-HANDOFF-001`, `SFT-ENG-ACCEPTANCE-BOUNDARY-001`, `SFT-ENG-COMPONENT-001`

Boundary: Exactly eight binary dimensions: 256 forms. Structural closure is depth-independent for positive finite components, versions, platforms, tests and lifecycle records; performance remains artifact, environment, user, method and operating-boundary limited.

Generation: Generate the literal Cartesian product of eight preregistered binary carrier, boundary, relation, record, evidence, provenance, generality and extension dimensions before external standards, products, tests or outcomes are opened; filter only by registered preservation properties.

The literal eight-axis product contains 256 forms:

- `carrier`: reject `answer-only-or-unversioned-artifact`; preserve `component-pair-exchange-contract-carrier` — The claim-specific engineering carrier is retained.
- `boundary`: reject `operating-test-or-lifecycle-boundary-erased`; preserve `interface-contract-bounded` — The operating, test, user and lifecycle boundary remains explicit.
- `relation`: reject `target-fitted-status-or-application-selected-relation`; preserve `typed-transfer-and-coordination-relation` — Only generated relations and admitted upstream laws act.
- `record`: reject `successful-output-only`; preserve `endpoints-signals-units-timing-errors-and-version-held` — The complete reconstructible engineering record is retained.
- `evidence`: reject `law-design-test-simulation-demonstration-conflated`; preserve `science-design-test-and-decision-classes-explicit` — Law, requirement, design, simulation, test, demonstration, performance and anomaly remain distinct.
- `provenance`: reject `opaque-build-prior-output-or-authority-selected`; preserve `root-bound-forward-translation` — The trace begins at the One and names every admitted law and engineering choice.
- `generality`: reject `single-platform-prototype-or-favourable-run-universalized`; preserve `positive-finite-extension-preserves-platforms-failures-and-versions` — Every lawful finite extension retains platforms, versions, failures and boundaries.
- `extension`: reject `free-weight-exception-or-silent-dependency`; preserve `no-extra-rule` — No rule beyond the frozen specification is introduced.

Exactly one form preserves every registered coordinate:

`component-pair-exchange-contract-carrier__interface-contract-bounded__typed-transfer-and-coordination-relation__endpoints-signals-units-timing-errors-and-version-held__science-design-test-and-decision-classes-explicit__root-bound-forward-translation__positive-finite-extension-preserves-platforms-failures-and-versions__no-extra-rule`

Base: The least translation retains one admitted law or requirement, one versioned artifact, one declared boundary, one testable relation and its complete record.

Successor: Adding one lawful finite component, interface, platform, requirement, test, failure, lifecycle stage or anomaly preserves every earlier identity, unfavorable row and receipt while appending its trace.

## Check

All 72 predictions and 18,432 candidates were sealed before source selection. The capability-closed prediction cannot read files, networks, clocks, environment or targets. Post-seal primary evidence tests the consequence and cannot select the law. Application performance never proves a scientific law; implementation failure does not automatically falsify one; simulation and demonstration remain distinct from observation, verification and validation. Evidence class: `source_bound_engineering_requirement_design_test_lifecycle_or_access_record` / `primary_standard_handbook_guidance_or_project_record_structural_correspondence`.
