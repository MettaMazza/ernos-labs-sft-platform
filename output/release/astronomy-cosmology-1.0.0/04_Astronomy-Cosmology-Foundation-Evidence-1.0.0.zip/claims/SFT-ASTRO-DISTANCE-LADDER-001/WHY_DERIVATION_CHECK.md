# Distance-ladder composition

Claim: `SFT-ASTRO-DISTANCE-LADDER-001`

## Why

A distance ladder is an explicit composition of anchors and rungs with covariance.

## Derivation

Dependencies: `SFT-FOUNDATION-ONE-001`, `SFT-FOUNDATION-FOLD-001`, `SFT-FOUNDATION-FOLD-DYNAMICS-001`, `SFT-MATH-EXACT-ARITHMETIC-001`, `SFT-MATH-GRAPH-NETWORK-001`, `SFT-MATH-ORDER-LATTICE-001`, `SFT-MATH-PROBABILITY-STATISTICS-001`, `SFT-MATH-DYNAMICAL-SYSTEMS-001`, `SFT-MATH-LOGIC-PROOF-001`, `SFT-INFO-QUANTITY-001`, `SFT-INFO-ENTROPY-UNCERTAINTY-001`, `SFT-INFO-CONSERVATION-LOSS-001`, `SFT-COMP-FORM-STATE-TRANSITION-001`, `SFT-PHYS-MEAS-OBSERVATION-CARRIER-001`, `SFT-PHYS-MEAS-UNCERTAINTY-001`, `SFT-PHYS-WAVE-PROPAGATION-001`, `SFT-PHYS-COSMO-REDSHIFT-001`, `SFT-PHYS-COSMO-DISTANCE-001`, `SFT-PHYS-COSMO-EXPANSION-001`, `SFT-PHYS-COSMO-STRUCTURE-GROWTH-001`, `SFT-PHYS-COSMO-BACKGROUND-001`, `SFT-PHYS-COSMO-DARK-BARYON-FRACTION-001`, `SFT-PHYS-GRAVITY-WAVE-001`, `SFT-PHYS-GRAVITY-HORIZON-001`, `SFT-PHYS-STELLAR-GALACTIC-TIDAL-TERMINAL-067`, `SFT-PHYS-STELLAR-NUCLEAR-COLLAPSE-TERMINAL-069`, `SFT-PHYS-COMPACT-HORIZON-THERMODYNAMICS-TERMINAL-071`, `SFT-CHEM-ELEM-ELEMENT-001`, `SFT-CHEM-STOICH-CONSERVATION-001`, `SFT-EARTH-HAZARD-RISK-HANDOFF-001`, `SFT-ASTRO-COMPACT-POPULATION-001`, `SFT-ASTRO-EXPANSION-RECORD-001`

Boundary: Exactly eight binary dimensions: 256 forms. Closure is depth-independent for positive finite extension; empirical correspondence remains source, object, place, epoch, instrument and protocol bounded.

Generation: Generate the literal Cartesian product of eight preregistered binary carrier, boundary, relation, record, evidence, provenance, generality and extension dimensions before external source identities or outcomes are opened; filter only by the registered preservation properties.

The literal eight-axis product contains 256 forms:

- `carrier`: reject `answer-only-or-unbounded-carrier`; preserve `anchor-rung-source-carrier` — The claim-specific carrier is retained.
- `boundary`: reject `frame-time-or-selection-erased`; preserve `ladder-version-bounded` — The exact observational boundary is explicit.
- `relation`: reject `imported-fitted-or-missing-relation`; preserve `calibration-composition-relation` — Only generated relations and admitted dependencies act.
- `record`: reject `favourable-output-incomplete-record`; preserve `anchors-rungs-populations-zero-points-and-covariance-held` — The complete required record is held.
- `evidence`: reject `observation-model-forecast-conflated`; preserve `evidence-class-explicit` — Direct, retrieval, proxy, reconstruction, model, forecast and missing remain distinct.
- `provenance`: reject `prior-answer-or-target-selected`; preserve `root-bound-forward-forcing` — The result traces through admitted dependencies to There Is No Nothing.
- `generality`: reject `one-favourable-object-erases-population`; preserve `positive-finite-extension-retains-all-rows` — Every finite extension retains favorable, adverse, absent and unresolved rows.
- `extension`: reject `free-parameter-exception-or-opaque-oracle`; preserve `no-extra-rule` — No rule beyond the registered structure is introduced.

Exactly one form preserves every registered coordinate:

`anchor-rung-source-carrier__ladder-version-bounded__calibration-composition-relation__anchors-rungs-populations-zero-points-and-covariance-held__evidence-class-explicit__root-bound-forward-forcing__positive-finite-extension-retains-all-rows__no-extra-rule`

Base: The least complete astronomical carrier retains source, path, observer, frame, relation, evidence class and root provenance.

Successor: Adding one lawful finite source, epoch, channel, object or population member preserves all earlier identities, adverse rows and boundaries and appends its trace.

## Check

All 72 predictions and 18,432 candidates were sealed before source selection. The capability-closed prediction cannot read files, networks, clocks, environment or targets. Post-seal primary evidence tests the consequence and cannot select the law. Evidence class: `source_bound_observation_archive_or_primary_measurement` / `primary_archive_or_measurement_correspondence`.

A catalogue, model, reconstruction, forecast, upper limit, non-detection and missing record remain distinct.
