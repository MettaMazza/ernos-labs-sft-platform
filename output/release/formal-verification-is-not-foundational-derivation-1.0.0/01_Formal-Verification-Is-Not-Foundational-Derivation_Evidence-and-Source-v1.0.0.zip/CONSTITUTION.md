# Smithian Fold Theory scientific constitution

## Purpose

This constitution defines what the third clean-room reconstruction may admit as
Smithian Fold Theory. Passing software tests is necessary but never sufficient
to establish a theorem, a natural law or an empirical result.

## 1. Foundation

The dependency spine begins with the self-proven theorem:

> There is no nothing.

A denial performs or contains a denial and therefore instantiates something.
The reconstruction must machine-check its own formal statement and every
subsequent dependency. No earlier SFT implementation is imported as proof.

The foundation forces the One, exact positive rational parts of the whole and
the Fold. Later forms must name their complete dependency route to this spine.

## 2. Mathematical domain

The SFT derivational domain contains:

- the One;
- exact positive rational parts of the whole;
- generated finite counts;
- exact labels, fibres, branches, words, relations and forms; and
- held orientation or complementary labels when conventional notation would
  write a sign.

The derivational domain does not admit:

- semantic numerical zero;
- negative quantities;
- irrational values;
- floating-point approximations as proof values;
- infinity as a completed object; or
- an ungenerated continuum as a premise.

The empty One is a form, not numerical zero. Opposed or signed phenomena must be
represented structurally through held labels, orientation, complement or branch
identity rather than by installing negative numbers as foundational objects.

Python and an operating system inevitably contain implementation indices,
booleans, empty containers, status codes and byte conventions. These are
quarantined host mechanics. They must never be promoted into SFT mathematical
objects or cited as derivational evidence. Empirical adapters may report
conventional decimal measurements, but those values remain measured records and
cannot flow into derivation.

## 3. No imported answer-producing priors

Consensus equations, conventional mathematical models, trained weights,
fitted parameters, benchmark answers and earlier SFT outputs cannot select an
SFT law. Earlier SFT results are nevertheless admissible and mandatory as
observational records of what the clean reconstruction must attempt to
reproduce or invalidate. Their stated questions, results, values, scopes and
falsifiers populate the V3 reconciliation census before derivation begins;
their code, certificates and answer-bearing artifacts remain excluded from the
V3 proof runtime and candidate selector.

Historical and conventional theories belong in `correspondence/` after an SFT
result has been independently derived. Correspondence may compare meanings,
domains and predictions; it cannot appear in a derivational dependency list.

Observations may supply an explicitly classified empirical relation. That
relation must expose exactly what was observed and must later be tested against
separate, sealed targets. Observational derivation is not permitted to masquerade
as direct forcing.

## 4. The assembled form is forced

Forcing ingredients is not enough. Every admitted assembled expression or law
must also pass:

1. **Generated candidate closure.** A stated generator produces the complete
   declared grammar rather than a hand-selected neighbor list.
2. **Minimality.** No simpler generated form yields the admitted result within
   the declared grammar.
3. **Named-shape uniqueness.** Exactly one same-size structural form survives
   the declared alternatives.
4. **Boundary declaration.** If the grammar is finite or size-bounded, the
   result is explicitly conditional unless a depth-independent certificate is
   supplied.

The generator, grammar, boundary, complete census and rejected alternatives
must be preserved as artifacts.

## 5. Dependency and provenance closure

Every value, operation, form and measurement receives a provenance class:

- direct forcing;
- forward forcing;
- constitutional relation;
- observational derivation;
- implementation identity;
- measured comparison;
- historical correspondence; or
- frontier hypothesis.

An unclassified dependency halts admission. Forward references are forbidden in
the dependency spine. Source hashes and artifact hashes bind every executable
result to the code and inputs that produced it.

## 6. Cold-readable modules

Every scientific module has three visibly separated voices:

- **WHY** - the scientific meaning, which is never evidence by itself;
- **DERIVATION** - checkable dependencies, generated candidates, eliminations
  and admitted form; and
- **CHECK** - proof checks, controls and measured comparison.

The derivation must state in plain language what forces the result, what the
alternatives were and why they fail. Any point that requires trust rather than
inspection is marked `OPEN`.

## 7. Claim admission

No claim is admitted without its package under `claims/<claim-id>/`. The
package must contain registration, dependencies, candidate grammar, census,
elimination receipt, controls, certificate, status and exact scope.

A unit test verifies implementation behavior. A proof certificate verifies a
declared mathematical construction. An empirical record verifies a sealed
relation to observation. These evidence classes are never substituted for one
another.

One versioned admission engine evaluates every v3 claim. Direct edits, prose
declarations or application results cannot bypass its gates. Any violation
halts admission and produces a rejection receipt identifying the failed law.

### 7.1 Immutable admission authority

The admission engine is frozen at Git tree
`ad30f4866c18b2adbade95a0b2de40d5caa61308` from commit
`501925b1c8553f49493d8efaeedfac9d8f42ab54`. Automated agents have no standing
authority to modify this tree, its public surface or its behavior. The existing
live-progress transparency commit
`bed68facb01d938b8c5257d0843506f40978e111` exposes verification progress but
does not alter scientific decisions and creates no broader exception.

No claim failure, branch deadline, desired measurement, prior SFT result,
publication objective or general instruction to continue authorizes an engine
change. Only Maria Smith may authorize a specifically identified engine edit,
and that authorization must be explicit before the edit occurs. Otherwise the
agent must halt and report the proposed change.

It is equally forbidden to evade immutability through a second engine, wrapper,
proxy, shadow ledger, direct census mutation, synthetic receipt, relaxed test,
target-aware validator, preselected survivor or protocol alteration designed
to obtain acceptance. A claim passes the frozen protocol as submitted or it
does not enter the model.

### 7.2 Canonical runtime-byte seal

The engine's committed Git tree and the actual bytes imported at runtime must
both equal the canonical authority. The Git tree is
`ad30f4866c18b2adbade95a0b2de40d5caa61308`; the exact 16-file runtime seal is
`sha256:4f4cdd7986808e6a6102d650c85e6093d6425e49f14a5f05d70fa05e6031d46a`.

Every researcher, reviewer and automated system must verify the runtime seal
before admission. The host package enforces the same check before engine
import. A changed, missing, added or symbolically substituted engine file, or a
changed seal manifest, halts the run as `VOID_INVALID_HALTED`. Editing the seal,
verifier, guard or tests to ratify a mismatch is a protocol violation, not a new
valid engine identity.

The seal proves that the same admission authority judged the package. It does
not replace source custody, candidate closure, controls, independent
recomputation or empirical validation, and it cannot make fitting, target
leakage or fabricated evidence admissible. Public cryptographic anchoring of a
seal or a newly versioned engine remains Maria Smith's publication decision.

## 8. Empirical constitution

Natural-science claims follow this order:

1. expose the observation or phenomenon used in development;
2. derive or constitutionally register a readable proposed relation;
3. preregister source, dependencies, inputs, targets, metrics and exclusions;
4. prevent target and score access during execution;
5. execute the complete declared candidate domain;
6. seal the prediction, trace and artifacts;
7. verify the seal through a separate evaluator;
8. open the experimental target only after the seal;
9. compute the registered measurements without feedback into the law;
10. preserve every favorable, unfavorable, failed and tampered row; and
11. state the exact falsification condition and tested boundary.

A blind opaque predictor may establish measured predictive reliability. It
cannot close an unstated natural law because blindness prevents answer leakage
but opacity still withholds the premise-to-result relation. Opaque systems may
serve as comparators or instruments, never as sources of SFT law.

## 9. Independent certification

Python is the readable v3 implementation. Important closures must also emit an
independent certificate, initially portable C or another deliberately separate
execution route. The certificate must reproduce the registered result from
declared inputs rather than print a stored answer.

Adverse controls must prove that altered premises, sources, artifacts,
candidate spaces and seals fail in the intended way.

## 10. Applications and engineering

Applications and engineering translations may test, falsify and demonstrate
closed laws. They cannot select, tune or retroactively redefine those laws.
Purpose-matched evidence is mandatory: a protein claim requires sealed protein
evidence, a game claim requires declared game evidence, and a computational
claim requires its own operational proof object.

Fold Protein, Fold Chess, Fold Go and Unison AI remain outside the v3
derivational authority until the relevant corpus branches are complete and
their fresh rebuilds are separately authorized.

## 11. Replication and earlier corpora

Earlier repositories and papers are preserved as provenance, observational and
comparison objects. V3 must not import their generated code, certificates or
answer files into a derivation. Every result previously stated as forced must,
however, be registered openly before reconstruction with its earlier statement,
value where present, scope, branch and falsification surface. This prior
observation is allowed to choose the question and completeness obligation; it
is not allowed to choose the V3 candidate grammar, eliminator or survivor.

The V3 execution route remains answer-isolated: it consumes only the
foundational theorem, admitted V3 dependencies and registered non-answering
structural inputs. Comparison with the openly registered prior result occurs
after the new result and its controls seal. Human knowledge of the earlier
answer is not misrepresented as blindness; independence is established by the
machine dependency boundary, complete enumeration, adverse controls and an
implementation-distinct certificate.

Agreement, representation-equivalence, stronger closure, weaker closure and
disagreement are all reportable outcomes. Disagreement is preserved and
investigated; v3 is not back-fitted to erase it.

## 12. Publication and authority

Branch closure is always **current-knowledge closure at an explicit registered
boundary**. It means that every obligation known and owned at the freeze date
has met the declared SFT standard and that the corresponding evidence is
closed. It never means that a science is permanently finished, locked against
new discovery or immune from correction. A branch remains open to lawful
extensions, stronger evidence, falsification and newly discovered obligations.
Such additions enter as new versioned claims through the unchanged admission
route; they do not silently rewrite earlier receipts.

No branch is complete for publication merely because every row in a narrow
frozen inventory passed. Before a current branch paper is eligible, every prior
source entry must be explicitly reviewed against that branch; every entry with
a branch-owned component must be decomposed without dropping any scientific
component; every resulting atomic obligation must have exactly one categorical
owner; every obligation owned by the branch must have a same-strength V3
disposition; and the paper evidence map must equal the live branch census.
Reviewed non-owning entries remain enumerated and hash-bound. A missing,
unreviewed, unowned or weaker result halts publication. The all-branch atomic
owner ledger remains mandatory for the final TOE paper.

Physical constants and dimensionless physical values belong to Physics. A
downstream Chemistry, Materials or Astronomy paper may consume their admitted
receipts but cannot substitute for their complete Physics derivation and
post-seal measurement treatment.

Maria Smith is the scientific author and publication authority. Automated
agents may implement, enumerate, test, reconcile and edit, but they cannot
promote a result, select official experiments or publish without explicit
authorization.

Authorization is action-specific. Permission for one commit, push, submission,
repository, experiment, paper, release, Zenodo version or DOI does not authorize
another. Instructions to continue scientific work do not authorize remote
mutation or deviation from the registered submission protocol.

Reviewer credentials do not override a failed mechanical gate. Mechanical
closure does not replace specialist empirical review where observation is
required.

## 13. Future v4 self-hosted reconstruction

V3 uses Python for accessibility and broad independent reproduction. It is not
declared the final native language of SFT.

When the v3 census is near-complete under an explicit frontier report, a fourth
clean-room reconstruction will derive and implement its language, compiler,
runtime, proof format and self-hosting principles inside SFT. V4 cannot author
v3 laws retroactively and must reproduce v3 through the same sealed comparison
discipline.

## 14. Amendment rule

This constitution may be clarified, but no amendment may weaken an evidence
gate for the purpose of admitting a desired result. Every amendment requires a
dated rationale, exact diff, adverse control update and Maria Smith's approval.
