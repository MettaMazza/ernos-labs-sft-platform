# Why SFT-MATH-OAI26-BINARY-CODE-MRRW-002 requires a derivation check

The frozen target is `MetricCodes.Johnson.binaryRate_lt_mrrw`. Its exact source text and quantifier order are in `source_statement.json`; its exact SFT-native proposition is in `translation.json`.

The OpenAI proof body and its declared axioms have no SFT derivational authority. The result may enter the model only after the registered proposition is independently forced from the named admitted dependencies, with arbitrary-input or complete-witness closure as appropriate. Inadmissibility alone is not a negation.
