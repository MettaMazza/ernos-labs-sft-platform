# Why SFT-COMP-OAI26-PERMANENT-FORMULA-001 requires a derivation check

The frozen target is `PermanentFormulaLowerBound.permanent_rational_formula_logarithmic_lower_bound`. Its exact source text and quantifier order are in `source_statement.json`; its exact SFT-native proposition is in `translation.json`.

The OpenAI proof body and its declared axioms have no SFT derivational authority. The result may enter the model only after the registered proposition is independently forced from the named admitted dependencies, with arbitrary-input or complete-witness closure as appropriate. Inadmissibility alone is not a negation.
