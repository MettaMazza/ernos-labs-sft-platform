Folder contains data used to produce Fig. 2 in main manuscript.

'xps_LiBzCovariance.dat': File contains covariance map between v(Li+Bz) and v(Bz+) to times denoted by "x". Format: 101-by-101 pixel array from 0-100 pixel values (x-vals are Li+, y-vals are Bz+)

'Li+_Ion_signal.dat': File contains coincidence filtered Li+ signal. Format: time (ps), Ion signal (arb. units).