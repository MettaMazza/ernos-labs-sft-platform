Folder contains data used to produce Fig. 3 in main manuscript.

'Li+BzCoincidenceFiltered.dat': File contains coincidence filtered Li+Bz velocity distributions vs. time. Format: 150x23 array of pixel values vs. time. 
Time-values are: [1, 1.4, 1.9, 2.6, 3.5, 4.8, 6.6, 9, 12.3, 17, 23, 32, 43, 59, 81, 111, 152, 208, 284, 390, 534, 731, 1000] in ps.

'Co(Li+Bz_Bz).dat': File contains coincidence filtered Li+Bz data for 15 different droplet sizes. Format: 23x15 array of times vs. ion signal for each T_nozzle temperature. time (ps), 20.5 K, 20 K, 19.5 K, 19 K, 18.5 K, 18 K, 17.5 K, 17 K, 16.5 K, 16 K, 15.5 K, 15 K, 14.5 K, 14 K, 13.5 K

't_total.dat': File contains mean value of log-normal distribution of reaction times vs. average radii of doped droplet distributions. Format: Average radius (Å), average t_total (ps), uncertainty lower (ps), uncertainty higher (ps).