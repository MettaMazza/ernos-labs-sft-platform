Folder contains data from RPMD simulations of Li+ in 3600 He atom droplets.

'Li-He3600_average_40ps.dat': RPMD simulation of Li+ in 3600 He atom droplet. Format: time (ps), r(Li+-COM) (Å), uncertainty_lower (Å), uncertainty_higher (Å)

'LiBenzene2-He3600_average.dat': RPMD simulation of Li+ in 3600 He atom droplet with Bz_2 in center averaged over 10 simulations. Format: time (ps), r(Li+-Bz_2) (Å), uncertainty_lower (Å), uncertainty_higher (Å)

'properties_LiBenzene2-He3600_theta10_final.dat': Properties of Li+ ion from simulation with Bz_2 in center for single simulation. Format: time (ps), r(Li+-Bz_2) (Å), coordination number N_c(Li+) (#He), r(Bz-Bz) (Å).

 
