Folder contains data for Supplementary Fig. 12

'R_values_doped_undoped.dat': File contains average radii of droplet size distributions vs. nozzle temperature. Both undoped and doped droplets are included. Format: T_nozzle (K), doped droplet radius (Å), undoped droplet radius (Å).
 