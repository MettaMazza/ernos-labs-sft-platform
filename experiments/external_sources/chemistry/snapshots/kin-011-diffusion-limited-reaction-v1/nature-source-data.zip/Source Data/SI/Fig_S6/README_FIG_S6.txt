Folder contains data used to produce Fig. 6 in Supplementary Information.

'Bz-Bz_distance_He1800_theta[x].dat': Files contain benzene-benzene distance during a RPMD simulation of Li+ and Bz_2 in a 1800-He atom droplet with the initial angle between Bz_2 and Li+ denoted by [x]. Format: time (ps), Bz-Bz distance (Å)

'Li_coordination_He1800_theta[x].dat': Files contain coordination number of Li+ during a RPMD simulation of Li+ and Bz_2 in a 1800-He atom droplet with the initial angle between Bz_2 and Li+ denoted by [x]. Format: time (ps), number of helium atoms around Li+ (#He)

'LiBz2_distance_He1800_theta[x].dat': Files contain Li+-Bz_2 distance during a RPMD simulation of Li+ and Bz_2 in a 1800-He atom droplet with the initial angle between Bz_2 and Li+ denoted by [x]. Format: time (ps), Li+-Bz_2 distance (Å)
