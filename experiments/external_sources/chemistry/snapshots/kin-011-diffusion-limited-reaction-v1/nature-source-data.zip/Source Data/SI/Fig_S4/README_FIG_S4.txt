Folder contains data used to produce Fig.  in Supplementary Information.

'potential_Li+He.dat': File contains calculated interaction energy between Li+ ion and He as a function of internuclear distance using analytical potential. Format: X (Å), Energy (meV)

'potential_Li+He_CCSD.dat': File contains calculated interaction energy between Li+ ion and He as a function of internuclear distance at the CCSD(T)/aug-cc-pVDZ. Format: X (Å), Energy (meV)