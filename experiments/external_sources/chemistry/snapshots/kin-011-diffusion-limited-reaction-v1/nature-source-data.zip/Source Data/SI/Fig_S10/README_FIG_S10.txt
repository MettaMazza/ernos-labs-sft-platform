Folder contains data for Supplementary Fig. 10

'MassSpectrum.dat': File contains m/q-spectrum of a time-resolved experiment. Format: m/q value (u/e), ion signal (arb. units)

'Li+BzImageRaw.dat': File contains raw VMI image of Li+Bz of a time-resolved experiment. Format: 301-by-301 pixel array.

'Li+Bz_Bz+_velocity_covariance.dat': File contains velocity covariance map between v(Li+Bz) and v(Bz+). Format: 101-by-101 pixel values.

'Li+Bz_Bz+_angular_covariance.dat': File contains angular covariance map between Li+Bz and Bz+. Format: 45-by-45 angular bins of 8 deg.

'Li+BzImageFiltered.dat': File contains coincidence-filtered VMI image of Li+Bz of a time-resolved experiment. Format: 301-by-301 pixel array.

'Li+BzVelocityDistributions.txt': File contains Abel inverted velocity distributions of raw and filtered VMI images of Li+Bz. Format: v_r (pixel), P(v_r) (arb. units) (raw), P(v_r) (arb. units) (filtered)

'Co(Li+Bz_Bz).dat': File contains integrated P(v_r) for filtered VMI image of Li+Bz as a function of time. Format: time (ps), Co(Li+Bz, Bz+) (arb. units)

 