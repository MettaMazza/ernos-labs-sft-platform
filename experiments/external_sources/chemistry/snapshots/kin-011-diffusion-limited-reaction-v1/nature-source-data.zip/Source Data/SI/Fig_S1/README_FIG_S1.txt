Folder contains data used to produce Fig. 1 in Supplementary Information.

'potential_Li-Bz_X.dat': File contains calculated interaction energy between Li and benzene as a function of distance between Li and Benzene COM in the plane of the molecule using analytic potential, for Li pointing towards an hydrogen atom. Format: X (Å), Energy (meV)

'potential_Li-Bz_X_CCSD.dat': File contains calculated interaction energy between Li and benzene as a function of distance between Li and Benzene COM in the plane of the molecule at the CCSD(T)/aug-cc-pVDZ level, for Li pointing towards an hydrogen atom. Format: X (Å), Energy (meV)

'potential_Li-Bz_Z.dat': File contains calculated interaction energy between Li and benzene as a function of distance between Li and Benzene COM normal to the plane of the molecule using analytic potential. Format: Z (Å), Energy (meV)

'potential_Li-Bz_Z_CCSD.dat': File contains calculated interaction energy between Li and benzene as a function of distance between Li and Benzene COM normal to the plane of the molecule at the CCSD(T)/aug-cc-pVDZ level. Format: Z (Å), Energy (meV)
