Folder contains data for Supplementary Fig. 11

'LeakValveYield.dat': File contains yield of coincidence filtered Li+Bz signal as a function of leak valve opening for Bz reservoir. Format: leak valve opening (arb. units), Co(Li+Bz, Bz+) (arb. units).

 