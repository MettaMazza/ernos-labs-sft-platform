Folder contains data used to produce Fig. 7 in Supplementary Information.

'charge_distant_Bz_[x]_[y].dat': Files contain charges of most distant Bz molecule as a function of distance between Li+ and Bz_2+. [x] denotes the method (CCD, DFT, MP2) and [y] denotes the charge calculation method (NBO, RESP). Format: Li+-Bz_2+ distance (Å), charge (e)

'charge_nearby_Bz_[x]_[y].dat': Files contain charges of nearest Bz molecule as a function of distance between Li+ and Bz_2+. [x] denotes the method (CCD, DFT, MP2) and [y] denotes the charge calculation method (NBO, RESP). Format: Li+-Bz_2+ distance (Å), charge (e)

'charge_Li_[x]_[y].dat': Files contain charges of Li+ as a function of distance between Li+ and Bz_2+. [x] denotes the method (CCD, DFT, MP2) and [y] denotes the charge calculation method (NBO, RESP). Format: Li+-Bz_2+ distance (Å), charge (e)
