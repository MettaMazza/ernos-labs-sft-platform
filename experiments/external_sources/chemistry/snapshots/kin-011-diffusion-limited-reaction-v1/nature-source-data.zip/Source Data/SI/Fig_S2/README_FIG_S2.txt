Folder contains data used to produce Fig. 2 in Supplementary Information.

'potential_Li+Bz_X.dat': File contains calculated interaction energy between Li+ ion and benzene as a function of distance between Li+ and benzene COM in the plane of the molecule along the C-H bond using analytic potential, for Li+ pointing towards an hydrogen atom. Format: X (Å), Energy (meV)

'potential_Li+Bz_X_[method].dat': File contains calculated interaction energy between Li+ and benzene as a function of distance between Li+ and benzene COM in the plane of the molecule along the C-H bond at the [DFT/wB97xD/6-311++G(d,p), MP2/6-311++G(d,p), no electrostatic contribution] level, for Li+ pointing towards an hydrogen atom. Format: X (Å), Energy (meV)

'potential_Li+Bz_Y.dat': File contains calculated interaction energy between Li+ and benzene as a function of distance between Li+ and benzene COM in the plane of the molecule between C-H bonds using analytic potential, for Li+ pointing perpendicular to a CC bond. Format: Y (Å), Energy (meV)

'potential_Li+Bz_Y_[method].dat': File contains calculated interaction energy between Li+ and benzene as a function of distance between Li+ and benzene COM in the plane of the molecule between C-H bonds at the [DFT/wB97xD/6-311++G(d,p), MP2/6-311++G(d,p), no electrostatic contribution] level, for Li+ pointing perpendicular to a CC bond. Format: Y (Å), Energy (meV)

'potential_Li+Bz_Z.dat': File contains calculated interaction energy between Li+ and benzene as a function of distance between Li+ and benzene COM normal to the plane of the molecule using analytic potential. Format: Z (Å), Energy (meV)

'potential_Li+Bz_Z_[method].dat': File contains calculated interaction energy between Li+ and benzene as a function of distance between Li+ and benzene COM normal to the plane of the molecule at the [DFT/wB97xD/6-311++G(d,p), MP2/6-311++G(d,p), no electrostatic contribution]  level. Format: Z (Å), Energy (meV)
