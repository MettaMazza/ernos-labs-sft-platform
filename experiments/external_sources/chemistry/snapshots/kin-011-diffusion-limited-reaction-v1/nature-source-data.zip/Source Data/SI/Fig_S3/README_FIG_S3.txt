Folder contains data used to produce Fig. 3 in Supplementary Information.

'charge_Li_DFT.dat': File contains calculated charges on Li+ ion as a function of distance between Li+ and benzene COM along the normal of the benzene plane using DFT/wB97xD/6-311++G(d,p). Format: Z (Å), ESP charge (e), NBO charge

'charge_Li_MP2.dat': File contains calculated charges on Li+ ion as a function of distance between Li+ and benzene COM along the normal of the benzene plane using MP2/6-311++G(d,p). Format: Z (Å), ESP charge (e), NBO charge
