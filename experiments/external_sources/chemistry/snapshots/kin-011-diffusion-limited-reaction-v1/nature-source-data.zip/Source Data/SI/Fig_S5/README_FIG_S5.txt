Folder contains data used to produce Fig. 5 in Supplementary Information.

'properties_LiBz2_theta_10_noHe.dat': File contains calculated observables related to simulation of the reaction between Li+ and Bz_2 in gas-phase. Format: time (ps), Li+-Bz_2 distance (Å), Bz-Bz distance (Å)